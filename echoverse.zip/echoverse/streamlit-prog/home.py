import streamlit as st
from gtts import gTTS
import base64
import os
import pathlib

st.set_page_config(page_title="EchoVerse", layout="centered", page_icon="🎙")


# --- Function to add gradient background and logo ---
def add_custom_styles():
    st.markdown(
        """
        <style>
        .stApp {
            background: linear-gradient(180deg, #800080, #ADD8E6); /* Lavender to Light Blue */
            background-size: cover;
            animation: gradient-animation 10s ease infinite; /* Optional: add subtle animation */
        }
        @keyframes gradient-animation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        /* Style for the logo in the sidebar */
        .sidebar .sidebar-content {
            padding-top: 0; /* Adjust padding if needed */
        }
        .logo-container {
            position: fixed; /* Fix the position */
            top: 50px; /* Distance from top */
            left: 30px; /* Distance from left */
            z-index: 1000; /* Ensure it's above other content */
        }
        .logo-img {
            width: 180px; /* Adjust logo size as needed */
            height: auto;
        }

        .st-key-genaud button{
           background-color: #800080;
          
        }
        
        </style>
        """,
        unsafe_allow_html=True,
    )


# --- Call the function to apply the background and styles ---
add_custom_styles()

# ----------------------------------------------------------------------------------
# THIS IS THE CORRECTED SECTION FOR HANDLING THE LOGO
# The code now reads the image file directly from your local system.
# Make sure the image file is in the same directory as your Python script.
# ----------------------------------------------------------------------------------
logo_path = "AJfQ9KQ3b5Zo0Vr7HLbKKvD7jDFh4k2g-removebg-preview.png"  # Your uploaded logo file name

# Check if the logo file exists
if os.path.exists(logo_path):
    # Read the image content in binary mode
    with open(logo_path, "rb") as f:
        logo_content = f.read()

    # Embed the logo using Base64 encoding
    st.markdown(
        f"""
        <div class="logo-container">
            <img src="data:image/png;base64,{base64.b64encode(logo_content).decode()}" class="logo-img">
        </div>
        """,
        unsafe_allow_html=True,
    )
else:
    st.error(
        f"Error: The logo file '{logo_path}' was not found. Please ensure it is in the same folder as this script."
    )

# ----------------------------------------------------------------------------------


# -------------------------------
# Title and description
# -------------------------------
# You might want to adjust the title's top margin if the logo overlaps
st.markdown(
    "<h1 style='margin-top: 0px;'>EchoVerse - AI Audiobook Creator</h1>",
    unsafe_allow_html=True,
)
st.write(
    "Transform your text into expressive, natural-sounding audio with customizable tones."
)


# -------------------------------
# File upload or text input
# -------------------------------
uploaded_file = st.file_uploader("Upload a .txt file", type=["txt"])
text_input = ""

if uploaded_file:
    text_input = uploaded_file.read().decode("utf-8")
else:
    text_input = st.text_area("Or paste your text below:", height=200)

# -------------------------------
# Tone Selection
# -------------------------------
tone = st.radio(
    "Select Tone for Narration:", ["Neutral", "Suspenseful", "Inspiring"], index=0
)


# -------------------------------
# Tone-based rewriting (placeholder)
# -------------------------------
def rewrite_text(original_text, tone):
    # 🔹 Placeholder for IBM Watsonx Granite LLM integration
    if tone == "Neutral":
        return original_text
    elif tone == "Suspenseful":
        return "🔹 [Suspenseful Rewrite] " + original_text
    elif tone == "Inspiring":
        return "✨ [Inspiring Rewrite] " + original_text
    return original_text


# -------------------------------
# Generate Audio
# -------------------------------
if st.button("Generate Audio", key="genaud"):
    if text_input.strip():
        rewritten_text = rewrite_text(text_input, tone)

        # Generate speech with gTTS
        tts = gTTS(text=rewritten_text, lang="en")
        filename = "output.mp3"
        tts.save(filename)

        # Play audio in app
        audio_file = open(filename, "rb").read()
        st.audio(audio_file, format="audio/mp3")

        # Download link
        b64 = base64.b64encode(audio_file).decode()
        href = f'<a href="data:audio/mp3;base64,{b64}" download="{filename}">⬇️ Download Audio</a>'
        st.markdown(href, unsafe_allow_html=True)

        # Show rewritten text for reference
        with st.expander("📖 View Rewritten Text"):
            st.write(rewritten_text)
    else:
        st.warning("⚠️ Please provide some text to generate audio.")
